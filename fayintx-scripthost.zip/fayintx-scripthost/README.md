# FayintX Script Host — Vercel Deploy Guide

## Struktur Project
```
fayintx-scripthost/
├── api/
│   ├── upload.js     → POST /api/upload
│   ├── get.js        → GET  /s/:id (raw Lua)
│   ├── list.js       → GET  /api/list
│   └── delete.js     → DELETE /api/delete
├── public/
│   └── index.html    → frontend UI
├── vercel.json       → routing config
└── package.json
```

## Step Deploy ke Vercel

### 1. Push ke GitHub
```bash
git init
git add .
git commit -m "initial: fayintx script host"
git remote add origin https://github.com/USERNAME/scripthost.git
git push -u origin main
```

### 2. Import ke Vercel
- Buka https://vercel.com/new
- Import repo GitHub lo
- Framework: **Other**
- Root directory: `/` (default)
- Klik Deploy

### 3. Buat Vercel KV Database
- Dashboard Vercel → Storage → Create Database → **KV**
- Nama: `scripthost-kv`
- Connect ke project lo
- Env vars otomatis ke-inject:
  - `KV_REST_API_URL`
  - `KV_REST_API_TOKEN`

### 4. Tambah Env Vars Manual
Di Vercel Dashboard → Settings → Environment Variables:
```
ADMIN_TOKEN   = token-rahasia-lo-sendiri
SITE_URL      = https://nama-project.vercel.app
```

### 5. Redeploy
Setelah env vars ditambah → Deployments → Redeploy

---

## Usage dari Executor Roblox

```lua
loadstring(game:HttpGet("https://nama-project.vercel.app/s/SCRIPTID"))()
```

## API Manual (opsional)

Upload via curl:
```bash
curl -X POST https://nama-project.vercel.app/api/upload \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Script","game":"Blox Fruits","code":"print(\"gas\")"}'
```

Delete (butuh admin token):
```bash
curl -X DELETE "https://nama-project.vercel.app/api/delete?id=SCRIPTID&token=TOKEN"
```
