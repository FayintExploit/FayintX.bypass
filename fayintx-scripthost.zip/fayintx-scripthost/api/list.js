// api/list.js
// GET /api/list?limit=50&offset=0
// Returns: { scripts: [...], total }

import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");

  const limit  = Math.min(parseInt(req.query.limit  || "50"), 100);
  const offset = parseInt(req.query.offset || "0");

  try {
    const total   = (await kv.get("scripts:total")) || 0;
    const rawList = await kv.lrange("scripts:list", offset, offset + limit - 1);

    const scripts = rawList
      .map(r => { try { return typeof r === "string" ? JSON.parse(r) : r; } catch { return null; } })
      .filter(Boolean);

    return res.status(200).json({ success: true, scripts, total });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
