// api/delete.js
// DELETE /api/delete?id=SCRIPTID&token=ADMIN_TOKEN

import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "DELETE, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "DELETE") return res.status(405).json({ error: "Method not allowed" });

  const { id, token } = req.query;

  // Admin token check
  if (token !== process.env.ADMIN_TOKEN)
    return res.status(403).json({ error: "Forbidden" });

  if (!id) return res.status(400).json({ error: "ID required" });

  try {
    await kv.del(`script:${id}`);

    // Remove from list
    const rawList = await kv.lrange("scripts:list", 0, -1);
    const filtered = rawList.filter(r => {
      try { const o = typeof r === "string" ? JSON.parse(r) : r; return o.id !== id; }
      catch { return true; }
    });
    await kv.del("scripts:list");
    if (filtered.length) await kv.rpush("scripts:list", ...filtered);
    await kv.decr("scripts:total");

    return res.status(200).json({ success: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
