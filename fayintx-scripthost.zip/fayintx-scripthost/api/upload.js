// api/upload.js
// POST /api/upload
// Body: { name, game, category, visibility, code }
// Returns: { id, loadstring_url }

import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();

  if (req.method !== "POST")
    return res.status(405).json({ error: "Method not allowed" });

  try {
    const { name, game, category, visibility, code } = req.body;

    if (!name || !code)
      return res.status(400).json({ error: "name dan code wajib diisi" });

    if (code.length > 500000)
      return res.status(400).json({ error: "Script terlalu besar (max 500KB)" });

    // Generate ID unik
    const id = generateId();
    const ts = Date.now();

    const scriptData = {
      id,
      name: name.slice(0, 100),
      game: (game || "Unknown").slice(0, 80),
      category: category || "Other",
      visibility: visibility === "private" ? "private" : "public",
      code,
      ts,
      hits: 0,
    };

    // Simpan ke Vercel KV
    await kv.set(`script:${id}`, JSON.stringify(scriptData));

    // Tambah ke index list (untuk library)
    const meta = { id, name: scriptData.name, game: scriptData.game, category: scriptData.category, visibility: scriptData.visibility, ts };
    await kv.lpush("scripts:list", JSON.stringify(meta));

    // Increment counter total
    await kv.incr("scripts:total");

    const loadstring_url = `loadstring(game:HttpGet("${process.env.SITE_URL || "https://your-app.vercel.app"}/s/${id}"))()`;

    return res.status(200).json({ success: true, id, loadstring_url });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Server error: " + err.message });
  }
}

function generateId() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let id = "";
  for (let i = 0; i < 8; i++) id += chars[Math.floor(Math.random() * chars.length)];
  return id;
}
