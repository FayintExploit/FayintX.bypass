// api/get.js
// GET /api/get?id=SCRIPTID  atau  GET /s/SCRIPTID
// Returns: raw Lua code (plain text) — langsung bisa di-loadstring

import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");

  const { id } = req.query;
  if (!id) return res.status(400).send("-- Error: ID tidak ada");

  try {
    const raw = await kv.get(`script:${id}`);
    if (!raw) return res.status(404).send(`-- Error: Script '${id}' tidak ditemukan`);

    const script = typeof raw === "string" ? JSON.parse(raw) : raw;

    // Increment hit counter (async, tidak blocking)
    kv.hincrby(`script:${id}:hits`, "count", 1).catch(() => {});

    // Kembalikan kode mentah — ini yang di-loadstring executor
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Cache-Control", "no-store");
    return res.status(200).send(script.code);
  } catch (err) {
    return res.status(500).send("-- Server error: " + err.message);
  }
}
